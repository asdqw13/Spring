package kr.co.korea.mapper;

public interface BoardMapper {

}
